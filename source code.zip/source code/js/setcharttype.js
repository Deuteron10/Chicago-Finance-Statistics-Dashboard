var charttype = "";

function setChartType(localchartType) {
  if (document.getElementById("filtercolumns").style.display == "none") {
	chartTypeSelected = localchartType;
	charttype = localchartType;
    var elementHandle = document.getElementById("chartTypeSelected");
    if (elementHandle != null) {
      elementHandle.innerHTML += 'Chart Type: ' + chartTypeSelected;
    }
    document.getElementById("filtercolumns").style.display = "block";
	document.getElementById("filtercolumnsHeader").style.display = "block";
  } else {
	 chartTypeSelected = localchartType;
	 charttype = localchartType;
    if (chartTypeSelected != null) {
      chartTypeSelected = null;
		  var elementHandle = document.getElementById("chartTypeSelected");
			if (elementHandle != null) {
		  elementHandle.innerHTML = '' ;
		}
    }
  }
  var strategy = new ChartStrategy(charttype);
  var filter = new ColSegment();
  filter.getAbstractFilter();

  if (charttype != "Stacked Chart") {
    document.getElementById("columnstackfiltertype").style.display = "none";
    document.getElementById("filterstackcolumns").style.display = "none";
	document.getElementById("filterstackcolumnsHeader").style.display = "none";
  } else if (charttype == "Stacked Chart" && dataobj.isstacksupport()) {
	document.getElementById("filterstackcolumnsHeader").style.display = "block";
    document.getElementById("filterstackcolumns").style.display = "block";
  }

  if (stackcols.length > 0 && charttype == "Stacked Chart" && dataobj.isstacksupport()) {
    document.getElementById("columnstackfiltertype").style.display = "inline-block";
    document.getElementById("filterstackcolumns").style.display = "block";
	document.getElementById("filterstackcolumnsHeader").style.display = "block";
  }

}
