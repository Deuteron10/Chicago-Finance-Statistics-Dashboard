class ChartStrategy {

	setChart(charttype){
	this.charttype=charttype;
	this.renderChart(this.charttype);
	}

	getChart(){
		return this.charttype;
	}

  renderChart(charttype) {
    if (charttype == "Vertical Bar Chart") {
      _chartVar = new Plot(new VerticalBarGraph());
    } else if (charttype == "Horizontal Bar Chart") {
      _chartVar = new Plot(new HorizontalBarGraph());
    } else if (charttype == "Pie Chart") {
      _chartVar = new Plot(new PieChart());
    } else if (charttype == "Line Chart") {
      _chartVar = new Plot(new LineGraph());
    } else if (charttype == "Stacked Chart" && dataobj.isstacksupport()) {
      _chartVar = new Plot(new StackedChart());
    } else if (charttype == "Stacked Chart" && !dataobj.isstacksupport()) {
      _chartVar = new Plot(new VerticalBarGraph());
      mchartdiv = "stchart";
    }
  }

  constructor(charttype) {
    this.setChart(charttype);
  }


}
