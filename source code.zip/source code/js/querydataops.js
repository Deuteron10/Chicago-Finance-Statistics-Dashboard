var DataFrame = dfjs.DataFrame;
var showNext = true;
var dataset;
var col;
var rowdata;
var gdf;
var dataobj;

function displayLoader(idname) {
  var elementHandle = document.getElementById(idname);
  elementHandle.innerHTML += '<div style="text-align:center" id="loading-msg"><img src="lib/loader.gif"></div>';
}

function hideLoadingImage() {
  if (document.getElementById('loading-msg') != null) {
    document.getElementById('loading-msg').remove();
  }
}

function getDataSetVal() {
  return document.getElementById("dataSetDropdownMenu").value;
}

function import_data(requested_dataset) {
  if ($.fn.dataTable.isDataTable('#table')) {
    alert("Select new Dataset after page is reloaded") ? "" : location.reload(true);
    showNext = false;
  } else {
    displayLoader('showDataset');
  }
  dataset = requested_dataset;
  dataobj = DataFactory.populateData(dataset);
  dataobj.getData();
  setTimeout(showdata, 4000, dataobj);
}

function showdata(data) {
  var df = data.getdf();
  gdf = df;
  col = df.listColumns();
  var dtcol = [];
  rowdata = df.toArray()

  for (var i = 0; i < col.length; i++) {
    dtcol[i] = {
      title: col[i]
    }
  }

  if (showNext) {
    $('#table').DataTable({
      data: rowdata,
      columns: dtcol,
      searching: false
    });


    hideLoadingImage();
    document.getElementById("chartTypeDropdownMenu").style.display = "inline-block";
	document.getElementById("chartTypeDropdownHeader").style.display = "inline-block";
  }
}
