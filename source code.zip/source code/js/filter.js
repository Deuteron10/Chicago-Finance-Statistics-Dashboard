var rowsegment = [];
var colsegment = [];
var stackcols = [];

class ColSegment extends AbstractFilter {

  getAbstractFilter() {
    if (colsegment.length == 0) {
      colsegment = dataobj.getfiltercolumsdata();
      for (var i = 0; i < colsegment.length; i++) {
        var elementHandle = document.getElementById('filtercolumns');
        if (elementHandle != null) {
          elementHandle.innerHTML += '<option href="#" value=' + col.indexOf(colsegment[i]) + '>' + colsegment[i] + '</option>';
        }
      }
    }
    var filter = new RowSegment();
    filter.getAbstractFilter();
  }

  getfiltercolumsdata(type) {

    var colvi;
    var colv;

    if (type == "stack") {
      colvi = document.getElementById('filterstackcolumns').value;
      colv = col[colvi];
    } else {
      colvi = document.getElementById('filtercolumns').value;
      colv = col[colvi];
    }

    if (dataobj.isdatetypecol(colv) && type != "stack") {
      if (document.getElementById('colcbsdiv') != null) {
        document.getElementById('colcbsdiv').remove();
      }

      if (document.getElementById('colcbsdivyear') != null) {
        document.getElementById('colcbsdivyear').remove();
      }

      if (document.getElementById('colcbsdivmonth') != null) {
        document.getElementById('colcbsdivmonth').remove();
      }

      var elementHandle = document.getElementById('columnfiltertype');
      if (elementHandle != null) {
        elementHandle.innerHTML += '<div class="checkbox" id="colcbsdivyear">Years: </div>';
      }
      var elementHandle = document.getElementById('columnfiltertype');
      if (elementHandle != null) {
        elementHandle.innerHTML += '<div class="checkbox" id="colcbsdivmonth">Months: </div>';
      }


      var dtstr = dataobj.getdatetypestr();

      var yearset = new Set();
      var monthset = new Set();
      var dtobj = {};

      for (var i = 0; i < rowdata.length; i++) {
        dtobj[i] = moment(rowdata[i][colvi], dtstr);
        yearset.add(dtobj[i].get('year'));
        monthset.add(dtobj[i].format('MMMM'));
      }

      var years = Array.from(yearset);
      var months = Array.from(monthset);

      for (var i = 0; i < years.length; i++) {
        var elementHandle = document.getElementById('colcbsdivyear');
        if (elementHandle != null) {
          elementHandle.innerHTML += '<label><input type="checkbox" name="yearchcolval" value="' + years[i] + '" id=ucol' + i + '>' + years[i] + '</label><label></label>';
        }
      }

      for (var i = 0; i < months.length; i++) {
        var elementHandle = document.getElementById('colcbsdivmonth');
        if (elementHandle != null) {
          elementHandle.innerHTML += '<label><input type="checkbox" name="monthchcolval" value="' + months[i] + '" id=ucol' + i + '>' + months[i] + '</label><label></label>';
        }
      }

      document.getElementById("columnfiltertype").style.display = "inline-block";

    } else {
      if (type == "stack" && charttype == "Stacked Chart") {

        if (document.getElementById('colcbsdivstack') != null) {
          document.getElementById('colcbsdivstack').remove();
        }

        var elementHandle = document.getElementById('columnstackfiltertype');
        if (elementHandle != null) {
          elementHandle.innerHTML += '<div class="checkbox" id="colcbsdivstack"></div>';
        }

        var allucolsval = gdf.distinct(colv).toArray();
        var ucolsval = [].concat.apply([], allucolsval);
        for (var i = 0; i < ucolsval.length; i++) {
          var elementHandle = document.getElementById('colcbsdivstack');
          if (elementHandle != null) {
            elementHandle.innerHTML += '<label><input type="checkbox" name="chcolvals" value="' + ucolsval[i] + '" id=ucol' + i + '>' + ucolsval[i] + '</label><label></label>';
          }
        }
        document.getElementById("filterstackcolumnsHeader").style.display = "block";
        document.getElementById("filterstackcolumns").style.display = "block";
        document.getElementById("columnstackfiltertype").style.display = "inline-block";
      } else {
        document.getElementById("columnstackfiltertype").style.display = "none";
        document.getElementById("filterstackcolumns").style.display = "none";
        document.getElementById("filterstackcolumnsHeader").style.display = "none";

        if (document.getElementById('colcbsdiv') != null) {
          document.getElementById('colcbsdiv').remove();
        }

        if (document.getElementById('colcbsdivyear') != null) {
          document.getElementById('colcbsdivyear').remove();
        }

        if (document.getElementById('colcbsdivmonth') != null) {
          document.getElementById('colcbsdivmonth').remove();
        }

        var elementHandle = document.getElementById('columnfiltertype');
        if (elementHandle != null) {
			//elementHandle.innerHTML += '<div class="checkbox" id="colcbsdiv"></div>';
          elementHandle.innerHTML += '<div class="checkbox" id="colcbsdiv"><table border="1" id="colcbstable"></table></div>';
        }



        var allucolsval = gdf.distinct(colv).toArray();
        var ucolsval = [].concat.apply([], allucolsval);
		var elementHandle = document.getElementById('colcbstable');
		var divString="";
        for (var i = 0; i < ucolsval.length; i++) {
          //var elementHandle = document.getElementById('colcbsdiv');

		  if(i==0){
			  //elementHandle.innerHTML+='<tr>';
			  divString+='<tr>';
		  }
          if (elementHandle != null) {
			divString+='<td><label><input type="checkbox" name="chcolval" value="' + ucolsval[i] + '" id=ucol' + i + '>' + ucolsval[i] + '</label><label></label></td>';
          }

		  if(i==ucolsval.length-1){
			  //elementHandle.innerHTML+='</tr>';
			  divString+='</tr>';
		  }
		  else if((i+1)%5==0){
			  //elementHandle.innerHTML+='</tr><tr>';
			  divString+='</tr><tr>';
		  }
        }
		elementHandle.innerHTML=divString;
        document.getElementById("columnfiltertype").style.display = "inline-block";
      }
    }

    if (dataobj.iscoltypestack(colv) && type != "stack") {
      if (stackcols.length == 0 && charttype == "Stacked Chart") {
        stackcols = dataobj.getstackcol();
        for (var i = 0; i < stackcols.length; i++) {
          var elementHandle = document.getElementById('filterstackcolumns');
          if (elementHandle != null) {
            elementHandle.innerHTML += '<option href="#" value=' + col.indexOf(stackcols[i]) + '>' + stackcols[i] + '</option>';
          }
        }
        document.getElementById("filterstackcolumns").style.display = "block";
        document.getElementById("filterstackcolumnsHeader").style.display = "block";
      } else if (stackcols.length > 0 && charttype == "Stacked Chart") {
        document.getElementById("filterstackcolumns").style.display = "block";
        document.getElementById("filterstackcolumnsHeader").style.display = "block";
        document.getElementById("columnstackfiltertype").style.display = "inline-block";
      }
    }
  }

}

class RowSegment extends AbstractFilter {

  getAbstractFilter() {
    if (rowsegment.length == 0) {
      rowsegment = dataobj.getrowsegmentdata();
      for (var i = 0; i < rowsegment.length; i++) {
        var elementHandle = document.getElementById('rowsegment');
        elementHandle.innerHTML += '<option href="#" value=' + col.indexOf(rowsegment[i]) + '>' + rowsegment[i] + '</option>';
      }
    }
  }
}
