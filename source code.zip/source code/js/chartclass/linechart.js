class LineGraph extends AbstractGraph {
	
	constructor(){
		super();
		mchartdiv = "linechart";
	}
	display(labels, clv, cdata, sumdata, colv, rowv) {
	var ctx = document.getElementById(mchartdiv);
	var myChart = new Chart(ctx, {
	type: 'line',
	responsive: true,
		data: {
		labels: labels,
		datasets: [{
			label: colv,
			data: cdata,
			fill: true,
			backgroundColor: "rgba(64,182,192,0.4)",
			borderColor: "rgba(65,182,192,1)",
			pointBorderColor: "rgba(66,172,192,12)",
			pointBackgroundColor: "#fff",
			borderWidth: 1
			}]
		},
	options: {
	title: {
	display: true,
	text: colv + ' vs. ' + rowv + ' ' + charttype
	},
	scales: {
	yAxes: [{
		ticks: {
		beginAtZero: true,
			callback: function(value, index, values) {
			if (sumdata) {
			return value.toLocaleString("en-US", {
			style: "currency",
			currency: "USD"
			});
			} else {
			return value
			}
			}
		}
	}]
	}
	}
	});
	document.getElementById(mchartdiv).scrollIntoView();
	}
}
