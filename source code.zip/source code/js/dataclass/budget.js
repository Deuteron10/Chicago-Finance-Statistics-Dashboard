instance=null;
class Budget extends Data {
  constructor() {
    super("data/budget.csv");
  }
  
   static getInstance(){
	  if(instance==null){
		  instance=new Budget();
	  }
	  return instance;
  }

  getData() {
    DataFrame.fromCSV(this.link).then(df => {
      cdf = {
        "dfobj": df
      };
    });
  }

  getdf() {
    return cdf["dfobj"];
  }

  getfiltercolumsdata() {
    return ["FUND TYPE","FUND CODE","FUND DESCRIPTION", "DEPARTMENT NUMBER", "DEPARTMENT DESCRIPTION", "APPROPRIATION AUTHORITY", "APPROPRIATION AUTHORITY DESCRIPTION", "APPROPRIATION ACCOUNT", "APPROPRIATION ACCOUNT DESCRIPTION"]

  }

  getrowsegmentdata() {
    return ["2012 ORDINANCE (AMOUNT $)"]
  }

  isdatetypecol(cname) {
    return false
  }

  iscoltypestack(cname) {
    return true
  }

  getstackcol() {
    return ["DEPARTMENT NUMBER"]
  }

  isstacksupport() {
    return true
  }

}
