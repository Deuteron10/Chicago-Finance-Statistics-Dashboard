let instance=null;
class Contract extends Data {
  constructor() {
    super("data/contract.csv");
  }
  
  getdatetypestr() {
    return "MM/DD/YYYY"
  }

  isstacksupport() {
    return true
  }


  getData() {
    DataFrame.fromCSV(this.link).then(df => {
      cdf = {
        "dfobj": df
      };
    });
  }
  
  iscoltypestack(cname) {
    return true
  }
  
   static getInstance(){
	  if(instance==null){
		  instance=new Contract();
	  }
	  return instance;
  }
  
  
  getrowsegmentdata() {
    return ["Award Amount"]
  }

  isdatetypecol(cname) {
    if (cname == "Approval Date") {
      return true
    } else {
      return false
    }
  }

  getstackcol() {
    return ["City", "State", "Zip", "Department"]
  }

  getdf() {
    return cdf["dfobj"];
  }

  getfiltercolumsdata() {
    return ["Purchase Order (Contract) Number","Revision Number","Contract Type","Approval Date","Department","Vendor Name","Vendor ID","Address 1","City","State","Zip"];
	
  }


  

}
