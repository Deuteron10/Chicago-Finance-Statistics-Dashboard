var chartTypeSelected=null;
var cdf = {};
var _chartVar;
var mchartdiv;

class AbstractGraph {
  display(labels, clv, cdata, sumdata, colv, rowv) {}
}

class Data {
  constructor(link) {
    this.link = link;
  }
  static getInstance() {}
  getData() {}
  getdf() {}
  getfiltercolumsdata() {}
  getrowsegmentdata() {}
  isdatetypecol(cname) {}
  iscoltypestack(cname) {}
  isstacksupport() {}
}

class AbstractFilter {
  getAbstractFilter() {}
}

class Plot {
  constructor(chart) {
    this.chart = chart;
  }
  display(labels, clv, cdata, sumdata, colv, rowv) {
    this.chart.display(labels, clv, cdata, sumdata, colv, rowv);
  }
}

function showStats() {
  document.getElementById("statscbs").style.display = "inline-block";
}

function hidestatsdata() {
  document.getElementById("showstats").style.display = "none";
}

class BarGraph extends AbstractGraph {
  display(labels, clv, cdata, sumdata, colv, rowv) {}
}
