class MathMetrics {

  showstatsdata(sdf) {

    var dmax, dmin, davg, dsd, dcount;
    var statHandle = document.getElementsByName('statschkbox');
    var stl = this.getCheckedBoxesStats(statHandle);
	var statString="";

    if (stl.length == 0) {
      hidestatsdata();
    } else {
      var rowv = document.getElementById('rowsegment').value;
      rowv = col[rowv];
      var statobj = {'chkmin': 'dmin','chkmax': 'dmax','chkavg': 'davg','chksd': 'dsd','chkc': 'dcount'}
       dmax = sdf.stat.max(rowv);
       dmin = sdf.stat.min(rowv);
       davg = sdf.stat.mean(rowv)
       dsd = sdf.stat.sd(rowv);
       dcount = sdf.count();

      var statobjval = {
        'dmin': dmin.toLocaleString("en-US", {
          style: "currency",
          currency: "USD"
        }),
        'dmax': dmax.toLocaleString("en-US", {
          style: "currency",
          currency: "USD"
        }),
        'davg': davg.toLocaleString("en-US", {
          style: "currency",
          currency: "USD"
        }),
        'dsd': dsd.toLocaleString("en-US", {
          style: "currency",
          currency: "USD"
        }),
        'dcount': dcount
      }

      var statobjff = {'dmin': 'Minimum','dmax': 'Maximum','davg': 'Average','dsd': 'Standard Deviation','dcount': 'Count'}

	  var elementHandle = document.getElementById("showstats");
	  statString="<table border='0px' style='margin-left:22%'><tr>";

      for (var key of Object.keys(statobj)) {
      if (document.getElementById(key).checked) {
      if (document.getElementById(statobj[key]) != null) {
        document.getElementById(statobj[key]).innerHTML = statobjff[statobj[key]] + ': ' + statobjval[statobj[key]];
      } else {
        if (elementHandle != null) {
      statString += '<td class="h4 padded" id="' + statobj[key] + '">' + statobjff[statobj[key]] + ': ' + statobjval[statobj[key]] + '</td>'
        }
      }
      } else {
      if (document.getElementById(statobj[key]) != null) {
        if (document.getElementById(statobj[key]) != null) {
          document.getElementById(statobj[key]).remove();
        }
      }
      }
      }

	  statString+='</tr></table>'
	  if (elementHandle != null) {
		  elementHandle.innerHTML+=statString;
	  }

      document.getElementById("showstats").style.display = "inline-block";
    }
  }

  getCheckedBoxesStats(cblist) {
    var cbvals = [];
    for (var i = 0; i < cblist.length; i++) {
      if (cblist[i].type == 'checkbox' && cblist[i].checked == true) {
        cbvals.push(cblist[i].value);
      }
    }
    return cbvals
  }

}
