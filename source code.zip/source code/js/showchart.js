function showChart() {
  chartInstance = new InitChart();
  chartInstance.formulate();

}
var colorSet = function(a) {
  var pool = [];
  for (i = 0; i < a; i++) {
    pool.push(dynamicColors());
  }
  return pool;
}

function showRowSegment() {
  var filtercolumn = new ColSegment();
  filtercolumn.getfiltercolumsdata('nostack');
  var elementHandle = document.getElementById("filtercolumnsSelected");
  if (elementHandle != null) {
      elementHandle.innerHTML += 'Chart Type Selected: ' + charttype;
  }
  document.getElementById("rowsegment").style.display = "block";
  document.getElementById("rowsegmentHeader").style.display = "block";
}

function showstackrows() {
  var filtercolumn = new ColSegment();
  filtercolumn.getfiltercolumsdata('stack');
}



function showRowRange() {
	document.getElementById("rowfiltertypeHeader").style.display = "block";
  document.getElementById("rowfiltertype").style.display = "inline";
  document.getElementById("rowfilterval").style.display = "inline";
  document.getElementById("graphshowbutton").style.display = "block";
  showStats();
}

var dynamicColors = function() {
  var r = Math.floor(Math.random() * 255);
  var g = Math.floor(Math.random() * 255);
  var b = Math.floor(Math.random() * 255);
  return "rgba(" + r + "," + g + "," + b + ",0.5)";
}

function checksumsel() {
  if (document.getElementById('rowfiltertype').value == "sum") {
    document.getElementById("rowfilterval").value = "";
    document.getElementById('rowfilterval').placeholder = "N/A for Sum";
    document.getElementById('rowfilterval').disabled = true;
  } else {
    document.getElementById('rowfilterval').disabled = false;
    document.getElementById('rowfilterval').placeholder = "enter value to filter";
  }
}
